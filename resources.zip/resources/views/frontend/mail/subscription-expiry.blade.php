
# Your Subscription is Expiring Soon!

Dear {{ $subscription->customer->name }},

We hope you’re enjoying our service! This is a friendly reminder that your subscription will expire on **{{ $subscription->plan_expiry_date }}**.

To continue enjoying uninterrupted access, please take a moment to renew your subscription. 

If you have any questions or need assistance, our support team is here to help!

Thank you for being a valued member of our community.

Best Regards,<br>
**Your Company Name**  



