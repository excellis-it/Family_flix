<footer class="footer">
    <div class="container">
      <ul>
        <li><a href="">Privacy Policy</a></li>
        <li><a href="">Terms & Conditions</a></li>
      </ul>
      <p>Copyright © {{date('Y')}}. All Rights Reserved. designed & developed by <a href="">excellis it</a>.</p>
    </div>
  </footer>
