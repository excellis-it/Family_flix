@extends('frontend.layouts.master')
@section('meta')
    <meta name="title" content="{{ $home_cms->meta_title ?? '' }}">
    <meta name="keywords" content="{{ $home_cms->meta_keyword ?? '' }}">
    <meta name="description" content="{{ $home_cms->meta_description ?? '' }}">
@endsection
@section('title', $home_cms->meta_title ?? '')
@push('styles')
    <style>
        .video-container {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 69vh;
            width: 70%;
            margin: 0 auto;
        }
    </style>
@endpush

@section('content')
    <section class="banner__slider banner_sec"
        style="background: url({{ Storage::url($home_cms->top_back_image) }});background-size: cover; background-position: center bottom;">
        <div class="slider stick-dots">
            <div class="slide">

                <div class="slide__content slide__content__left">
                    <div class="slide__content--headings text-left">
                        <div class="bnr-text-p">
                            <p>{{ $home_cms->top_short_title }}</p>
                        </div>
                        <h1 class="title">
                            <!-- <span>Welcome to</span> -->
                            {{ $home_cms->top_main_title }}
                        </h1>
                        <div class="sign-up-btn mt-4">
                            <a href="{{ route('affiliate-marketer.register') }}">{{ $home_cms->top_button_text }}</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="vdo-img">
            <img src="{{ Storage::url($home_cms->section1_main_image) }}" alt="{{$home_cms->section1_main_img_alt_tag ?? ''}}" />
        </div>
    </section>
    <section class="access-sec">
        <div class="access-bg-img">
            <img src="{{ Storage::url($home_cms->section1_back_image) }}" alt="{{$home_cms->section1_back_img_alt_tag ?? ''}}" />
        </div>
        <div class="container">
            <div class="access-div">
                <div class="access-div-wrap">
                    <div class="row justify-content-center">
                        @include('frontend.partials.top_grid')
                    </div>
                </div>
            </div>
        </div>

    </section>
    <section class="one-place">
        <div class="one-place-img text-end">
            <img src="{{ Storage::url($home_cms->section2_main_image) }}" alt="{{$home_cms->section2_main_img_alt_tag ?? ''}}" />
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-lg-6">
                        <div class="one-place-div">
                            <div class="one-place-text">
                                <div class="heading-white">
                                    <h3>
                                        {{ $home_cms->section2_title }}
                                    </h3>
                                    <p>
                                        {{ $home_cms->section2_description }}
                                    </p>
                                    <div class="">
                                        <a href="" class="view-btn">{{ $home_cms->section2_short_title }}<span><i
                                                    class="fa-solid fa-arrow-right"></i></span></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="one-place-circle">
                            <div data-elementor-type="wp-page" data-elementor-id="10" class="elementor elementor-10">
                                <div class="elementor-element elementor-element-3d96d24 e-con-full elementor-hidden-mobile e-flex e-con e-parent"
                                    data-id="3d96d24" data-element_type="container" data-settings='{"content_width":"full"}'
                                    data-core-v316-plus="true">
                                    <div class="elementor-element elementor-element-94008c1 e-con-full elementor-hidden-mobile e-flex e-con e-child"
                                        data-id="94008c1" data-element_type="container"
                                        data-settings='{"content_width":"full","background_background":"classic"}'>
                                        <div class="elementor-element elementor-element-9907f7f elementor-widget elementor-widget-eael-interactive-circle"
                                            data-id="9907f7f" data-element_type="widget"
                                            data-widget_type="eael-interactive-circle.default">
                                            <div class="elementor-widget-container">
                                                <div id="eael-interactive-circle-9907f7f" class="eael-interactive-circle"
                                                    data-tabid="9907f7f">
                                                    <div class="eael-circle-wrapper eael-interactive-circle-preset-1 eael-interactive-circle-event-hover eael-circle-responsive-view eael-interactive-circle-animation-3"
                                                        data-animation="eael-interactive-circle-animation-3"
                                                        data-autoplay="0" data-autoplay-interval="2000">
                                                        <div class="eael-circle-info" data-items="8">

                                                            <div class="eael-circle-btn-content">
                                                                <div class="eael-circle-content">
                                                                    <img decoding="async" style="width: 200px"
                                                                        src="{{ Storage::url($home_cms->section2_main_icon) }}"
                                                                        alt="Logo" />
                                                                </div>
                                                            </div>
                                                            @foreach ($ott_icons as $index => $ott_icon)
                                                                <div class="eael-circle-inner">
                                                                    <div
                                                                        class="eael-circle-item elementor-repeater-item-c5a3e9d">
                                                                        <div class="eael-circle-btn"
                                                                            id="eael-circle-item-{{ $ott_icon->id }}">
                                                                            <div class="eael-circle-icon-shapes classic">
                                                                                <div class="eael-shape-1"></div>
                                                                                <div class="eael-shape-2"></div>
                                                                            </div>
                                                                            <div class="eael-circle-btn-icon">
                                                                                <div class="eael-circle-icon-inner">
                                                                                    <img
                                                                                        src="{{ Storage::url($ott_icon->icon) }}" />
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                            @endforeach
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        </div>
    </section>
    <section class="entertainment-sec">
        <div class="entertainment-bg">
            <img src="{{ Storage::url($home_cms->section2_back_image) }}" alt="{{$home_cms->section2_back_img_alt_tag ?? ''}}" />
        </div>
        <div class="entertainment-div">
            @include('frontend.partials.entertainment')

        </div>
    </section>
    <section class="works-sec">
        <div class="works-sec-bg">
            <img src="{{ Storage::url($home_cms->section3_back_image) }}" alt="{{$home_cms->section3_back_img_alt_tag ?? ''}}" />
        </div>
        <div class="works-div-wrap">
            <div class="container">
                <div class="row justify-content-center align-items-end">
                    <div class="col-lg-9">
                        <div class="works-div-img">
                            <div class="entertainment-head">
                                <div class="heading-1 heading-white mb-5">
                                    <h2>{{ $home_cms->section3_title }}<span class="dot">.</span></h2>
                                </div>
                            </div>
                            <img src="{{ Storage::url($home_cms->section3_main_image) }}" alt="{{$home_cms->section3_main_img_alt_tag ?? ''}}" />
                            <div class="play-btn">
                                <button type="button" class="play-btn" data-bs-toggle="modal" data-src=""
                                    data-bs-target="#myModal"><span><i class="fa-solid fa-play"></i></span></button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    @if (count($products) > 0)
        <section class="unbeatable-sec">
            <div class="unbeatable-bg">
                <img src="{{ Storage::url($home_cms->section4_back_image) }}" alt="{{$home_cms->section4_back_img_alt_tag ?? ''}}" />
            </div>
            <div class="entertainment-div">
                <div class="container">
                    <div class="row justify-content-center">
                        <div class="col-lg-6">
                            <div class="entertainment-head">
                                <div class="heading-1 text-center">
                                    <h3>{{ $home_cms->section4_title }}<span class="dot">.</span></h3>
                                    <p>
                                        {{ $home_cms->section4_description }}
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="unbeatable-slider">
                @include('frontend.partials.unbeatable-slider')
            </div>
        </section>
    @endif
    <section class="kids-sec">
        <div class="kid-bg">
            <img src="{{ Storage::url($home_cms->section5_back_image) }}" alt="{{$home_cms->section5_back_img_alt_tag ?? ''}}" />
        </div>
        <div class="kids-div">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-lg-10">
                        <div class="row justify-content-center">
                            <div class="col-lg-6">
                                <div class="entertainment-head">
                                    <div class="heading-1">
                                        <h3>{{ $home_cms->section5_main_title }}<span class="dot">.</span></h3>
                                        <p>
                                            {!! $home_cms->section5_main_description !!}
                                        </p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="kid-tv-img">
                                    <img src="{{ Storage::url($home_cms->section5_main_image) }}" alt="{{$home_cms->section5_main_img_alt_tag ?? ''}}" />
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="pricing-sec">
        <div class="pricing-bg">
            <img src="{{ Storage::url($home_cms->plan_section_back_image) }}" alt="{{$home_cms->plan_section_back_img_alt_tag ?? ''}}" />
        </div>
        <div class="container">
            <div class="pricing-sec-wrap">
                <div class="row justify-content-center">
                    <div class="col-lg-8">
                        <div class="entertainment-head">
                            <div class="heading-1 heading-white text-center">
                                <h3>{{ $home_cms->plan_section_title }}<span class="dot">.</span></h3>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            @include('frontend.partials.plans')
        </div>
    </section>


    {{-- modal open --}}
    <div class="modal modal-1 fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog modal-xl" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <!-- Adjust width and height attributes for the iframe -->
                    <!--<iframe width="1280" height="720" src="{{ Storage::url($home_cms->section3_video_link) }}" title="YouTube video player" frameborder="0"   allow="accelerometer; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>-->
                    <video width="100%" height="720" controls>
                        <source src="{{ Storage::url($home_cms->section3_video_link) }}" type="video/mp4">
                    </video>
                </div>
            </div>
        </div>
    </div>

    {{-- modal close --}}

    <div class="scroll-top">
        <a id="scroll-top-btn"></a>
    </div>
@endsection
